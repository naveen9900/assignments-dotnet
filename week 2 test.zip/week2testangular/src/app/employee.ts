export class employee{
    department:number;
    name:string;
    groupname:string;
    modifieddate:Date;
}
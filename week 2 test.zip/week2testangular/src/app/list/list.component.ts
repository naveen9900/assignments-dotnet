import { Component, OnInit } from '@angular/core';
import { employee } from './../employee';
import { EmployeeService } from './../employee.service';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http'
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
emp:employee;
updatediv=false;
indexposition:number;
emplist:employee[];
  constructor(private em:EmployeeService,private route:Router) {
    this.emplist=this.em.showemployee()
   }

  ngOnInit() {
  }
  edit(index:number){
    console.log("Index"+index)
    this.updatediv=true;
    this.emp=this.emplist[index];
    this.em.update(this.emp,this.indexposition)
  }
  deleteemployee(index:number){
    this.em.delete(index);
  }


}

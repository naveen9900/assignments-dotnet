import { Component, OnInit, Input } from '@angular/core';
import { employee } from './../employee';
import { EmployeeService } from './../employee.service';
import { Router } from '@angular/router'
@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
emp:employee;
updatedindex:number;
@Input()
rowindex:number;
  constructor(private em:EmployeeService,private route:Router) { }

  ngOnInit() {
  }

  updateemployee(index:number){}

}

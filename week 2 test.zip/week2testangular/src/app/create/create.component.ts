import { Component, OnInit } from '@angular/core';
import { employee } from './../employee';
import { EmployeeService } from './../employee.service';
import { Router } from '@angular/router';
import {NgForm} from '@angular/forms';
@Component({
  selector: 'app-create',
  templateUrl: './create.component.html',
  styleUrls: ['./create.component.css']
})
export class CreateComponent implements OnInit {
emp=new employee();
  constructor(private em:EmployeeService,private route:Router) { }

  ngOnInit() {
  }
  saveemployee():void{
    this.em.save(this.emp);
    console.log(this.emp)
      this.route.navigate(['list']);
    }
  updateemployee():void{
    this.em.save(this.emp);
      this.route.navigate(['list']);
    }

}

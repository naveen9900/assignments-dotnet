import { Injectable } from '@angular/core';
import { employee } from './employee'

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
private emplist:employee[]=[
  {department:1,name:'Engineering',groupname:'Research and Development',modifieddate:new Date('2002-10-17')},
  {department:2,name:'Tool Design',groupname:'Research and Development',modifieddate:new Date('2002-10-30')},
  {department:3,name:'Sales',groupname:'Sales and Marketing',modifieddate:new Date('2002-10-23')},
  {department:4,name:'Marketing',groupname:'Sales and Marketing',modifieddate:new Date('2002-10-18')},
  {department:5,name:'Purchasing',groupname:'nventory Management',modifieddate:new Date('2002-10-19')},
  {department:6,name:'Production Control',groupname:'Manufacturing',modifieddate:new Date('2002-10-15')},
  
];
  constructor() { }

showemployee(){
return this.emplist;
}
save(emp:employee){
  this.emplist.push(emp);
}
update(emp:employee,index:number){
this.emplist[index]=emp;
}
delete(index:number){
  this.emplist.splice(index,1);
}
}

﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;

namespace UnitTestProject1_Selenium_
{
    [TestClass]
    public class UnitTest1
    {

        [TestMethod]
        public void TestMethod1()
        {
            IWebDriver driver;
            driver=new ChromeDriver("C:\\Selenium Jar");
            driver.Url = "https://www.google.com";
            string nav =  "Dxc Technology" ;
            driver.FindElement(By.Name("q")).SendKeys(nav);
            Thread.Sleep(3000);
            driver.FindElement(By.ClassName("gNO89b")).Click();
            Thread.Sleep(3000);
            Console.WriteLine(driver.Title);
            Console.WriteLine(driver.FindElement(By.XPath("/html/body/div[7]/div[3]/div[7]/div[1]/div/div/div/div")));
            Thread.Sleep(3000);
            if((driver.Title).Contains(nav))
            {
                Console.WriteLine("PASS");
            }
            else
            {
                Console.WriteLine("FAIL");
            }
            driver.Close();
        }
        
    }
}

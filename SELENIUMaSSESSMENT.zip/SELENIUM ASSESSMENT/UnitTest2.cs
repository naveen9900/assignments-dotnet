﻿using System;
using System.Text;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
//using OpenQA.Selenium.Firefox;
using System.Threading;
using OpenQA.Selenium.Interactions;

namespace UnitTestProject1_Selenium_
{
    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void TestMethod1()
        {

            IWebDriver driver;
            driver = new ChromeDriver("C:\\Selenium Jar");
            //driver = new FirefoxDriver("C:\\Selenium Jar");
            driver.Url = "http://www.youcandealwithit.com/";
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(30);
            IWebElement borrowers = driver.FindElement(By.XPath("/html/body/div[1]/ul[2]/li[1]/a"));
            Actions action = new Actions(driver);
            action.MoveToElement(driver.FindElement(By.XPath("/html/body/div[1]/ul[2]/li[1]/a"))).Build().Perform();
            driver.FindElement(By.LinkText("Calculators & Resources")).Click();
            Thread.Sleep(2000);
            string calres = driver.FindElement(By.LinkText("Calculators & Resources")).Text;

            if (driver.Title.Contains(calres))
            {
                driver.FindElement(By.LinkText("Calculators")).Click();
                Thread.Sleep(2000);
                string cal = driver.FindElement(By.LinkText("Calculators")).Text;
                Console.WriteLine("Calculator & Resources Link PASSED");
                if (driver.Title.Contains(cal))
                {
                    driver.FindElement(By.LinkText("Budget Calculator")).Click();
                    Thread.Sleep(2000);
                    string budcal = driver.FindElement(By.LinkText("Budget Calculator")).Text;
                    Console.WriteLine("Calculator Link PASSED");
                    if (driver.Title.Contains(budcal))
                    {
                        driver.FindElement(By.Id("food")).SendKeys("1000");
                        driver.FindElement(By.Id("clothing")).SendKeys("1500");
                        driver.FindElement(By.Id("shelter")).SendKeys("7000");
                        driver.FindElement(By.Id("monthlyPay")).SendKeys("20000");
                        driver.FindElement(By.Id("monthlyOther")).SendKeys("5000");
                        driver.FindElement(By.Id("totalMonthlyExpenses")).SendKeys("8000");
                        Thread.Sleep(2000);
                        driver.FindElement(By.Id("underOverBudget")).Click();
                        Thread.Sleep(2000);
                        Console.WriteLine("Budget Calculator Link PASSED");
                        double num=Double.Parse(driver.FindElement(By.Id("underOverBudget")).GetAttribute("value"));
                        double num1 = Double.Parse(driver.FindElement(By.Id("totalMonthlyExpenses")).GetAttribute("value"));
                        double num2 = Double.Parse(driver.FindElement(By.Id("monthlyPay")).GetAttribute("value"));
                        Console.WriteLine("UnderOverBudget: "+num);
                        if(num1>=num2)
                        {
                            Console.WriteLine("You are in Warren Buffet");
                        }
                        else
                        {
                            Console.WriteLine("You are an VM");
                        }
                        driver.Close();
                    }
                    else
                    {
                        Console.WriteLine("Test Case Failed at Budget Calculator Link");
                    }

                }
                else
                {
                    Console.WriteLine("Test Case Failed at Calculators Link");
                }
            }
            else
            {
                Console.WriteLine("Test Case Failed at Calculators & Resources Link");
            }
            

        }
    }
}
    
